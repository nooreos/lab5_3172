import React from 'react';

function Projects() {
  return (
    <div>
      <h1>Projects</h1>
      <p>Project details coming soon... Placeholder until next lab</p>
    </div>
  );
}

export default Projects;
